import os
import torch
import argparse

if torch.cuda.is_available():
    device = torch.device('cuda')
else:
    device = torch.device('cpu')

# device = torch.device('cpu')


def get_args():
    parser = argparse.ArgumentParser(description="MTNet's args")
    # Operation environment
    parser.add_argument('--seed',
                        type=int,
                        default=920,
                        help='Random seed')
    parser.add_argument('--device',
                        type=str,
                        default=device,
                        help='Running on which device')
    # Data
    parser.add_argument('--dataset',
                        type=str,
                        default='NYC',
                        # default='TKY',
                        help='Dataset name')
    parser.add_argument('--data_train',
                        type=str,
                        default='dataset/NYC/NYC_train.csv',
                        # default='dataset/TKY/TKY_train.csv',
                        help='Training data path')
    parser.add_argument('--data_val',
                        type=str,
                        default='dataset/NYC/NYC_val.csv',
                        # default='dataset/TKY/TKY_val.csv',
                        help='Validation data path')
    parser.add_argument('--data_test',
                        type=str,
                        default='dataset/NYC/NYC_test.csv',
                        # default='dataset/TKY/TKY_test.csv',
                        help='Testing data path')
    parser.add_argument('--time_units',
                        type=int,
                        default=48,
                        help='Time unit is 0.5 hour, 24/0.5=48')
    parser.add_argument('--time_feature',
                        type=str,
                        default='norm_in_day_time',
                        help='The name of time feature in the data')

    # Model hyper-parameters
    parser.add_argument('--user_embed_dim',
                        type=int,
                        default=128,
                        help='User embedding dimensions')
    parser.add_argument('--poi_embed_dim',
                        type=int,
                        default=128,
                        help='POI embedding dimensions')
    parser.add_argument('--time_embed_dim',
                        type=int,
                        default=32,
                        help='Time embedding dimensions')
    parser.add_argument('--cat_embed_dim',
                        type=int,
                        default=32,
                        help='Category embedding dimensions')
    parser.add_argument('--gcn_dropout',
                        type=float,
                        default=0.3,
                        help='Dropout rate for gcn')
    parser.add_argument('--gcn_hidden_dim',
                        type=list,
                        default=[32, 64],
                        help='List of dimension for gcn hidden layers')
    parser.add_argument('--transformer_hidden_dim',
                        type=int,
                        default=1024,
                        help='Hidden layer dimension in TransformerEncoder')
    parser.add_argument('--transformer_layers',
                        type=int,
                        default=2,
                        help='Number of Transformer encoder layer')
    parser.add_argument('--transformer_heads',
                        type=int,
                        default=2,
                        help='Number of heads in MultiHeadAttention')
    parser.add_argument('--transformer_dropout',
                        type=float,
                        default=0.3,
                        help='Dropout rate for transformer')
    parser.add_argument('--time_loss_weight',
                        type=int,
                        default=10,
                        help='Scale factor for the time loss term')
    parser.add_argument('--node_attn_hidden_dim',
                        type=int,
                        default=128,
                        help='Node attn map hidden dimensions')
    parser.add_argument('--cell_type',
                        type=str,
                        default='nary',
                        help='TreeLSTM cell type')
    parser.add_argument('--x_size',
                        type=int,
                        default=256,
                        help='for TreeLSTM')
    parser.add_argument('--h_size',
                        type=int,
                        default=128,
                        help='for TreeLSTM')
    parser.add_argument('--nary',
                        type=int,
                        default=3,
                        help='n-ary tree')

    # Training hyper-parameters
    parser.add_argument('--batch_size',
                        type=int,
                        default=10,
                        help='Batch size.')
    parser.add_argument('--epochs',
                        type=int,
                        default=200,
                        help='Number of epochs to train.')  # 200
    parser.add_argument('--lr',
                        type=float,
                        default=0.001,
                        help='Initial learning rate.')
    parser.add_argument('--lr-scheduler-factor',
                        type=float,
                        default=0.1,
                        help='Learning rate scheduler factor')
    parser.add_argument('--weight_decay',
                        type=float,
                        default=5e-4,
                        help='Weight decay (L2 loss on parameters).')

    # Experiment config
    parser.add_argument('--save_weights',
                        action='store_true',
                        default=True,
                        help='Whether to save the model')
    parser.add_argument('--save_embeds',
                        action='store_true',
                        default=False,
                        help='whether to save the embeddings')
    parser.add_argument('--need_plot',
                        type=bool,
                        default=False,
                        help='Whether to plot the tree')
    parser.add_argument('--workers',
                        type=int,
                        default=0,
                        help='Num of workers for dataloader.')
    parser.add_argument('--exist-ok',
                        action='store_true',
                        help='Existing project/name ok, do not increment')
    parser.add_argument('--no-cuda',
                        action='store_true',
                        default=False,
                        help='Disables CUDA training.')
    parser.add_argument('--mode',
                        type=str,
                        default='client',
                        help='Python console use only')
    parser.add_argument('--port',
                        type=int,
                        default=19923,
                        help='Python console use only')
    parser.add_argument('--save_path',
                        type=str,
                        default='./checkpoints/',
                        help='Checkpoints saving path')

    args = parser.parse_args()
    return args
