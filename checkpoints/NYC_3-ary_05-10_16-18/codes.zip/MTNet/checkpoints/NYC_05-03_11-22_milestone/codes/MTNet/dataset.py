import pandas as pd
from tqdm import tqdm
from torch.utils.data import Dataset, DataLoader


# class TrajectoryDataset(Dataset):
#     def __init__(self, data_df, user_id2idx_dict, POI_id2idx_dict, POI_idx2cat_idx_dict, nary, desc='train'):
#         self.trajectories = {}
#
#         data_df['local_time'] = pd.to_datetime(data_df['local_time'])  # convert time column to datetime format
#         data_df = data_df.sort_values(['user_id', 'local_time'])  # sort
#
#         for trajectory_id, trajectory in tqdm(data_df.groupby('trajectory_id'), desc=f"Prepare {desc} dataset"):
#             user_id = trajectory_id.split('_')[0]
#             # Avoid exception
#             if user_id not in user_id2idx_dict.keys():
#                 continue
#             user_idx = user_id2idx_dict[user_id]
#             traj_idx = len(self.trajectories)
#             self.trajectories[traj_idx] = []
#
#             if len(trajectory) <= 15:
#                 if len(trajectory) <= nary + 1:
#                     self.trajectories.pop(traj_idx)
#                     continue
#                 flag = 0
#                 for index in range(len(trajectory) - 1):
#                     _, pid, _, _, _, lat, long, _, _, _, _, norm_in_day, _, _, _ = trajectory.iloc[index]
#                     _, next_pid, _, _, _, _, _, _, _, _, _, next_norm_in_day, _, _, _ = trajectory.iloc[index + 1]
#                     # Avoid exception
#                     if pid not in POI_id2idx_dict.keys() or next_pid not in POI_id2idx_dict.keys():
#                         flag = 1
#                         break
#                     POI_idx = POI_id2idx_dict[pid]
#                     cat_idx = POI_idx2cat_idx_dict[POI_idx]
#                     next_POI_idx = POI_id2idx_dict[next_pid]
#                     next_cat_idx = POI_idx2cat_idx_dict[next_POI_idx]
#                     features = [user_idx, POI_idx, cat_idx, (lat, long), norm_in_day]
#                     labels = [next_POI_idx, next_norm_in_day, next_cat_idx]
#                     checkin = {'index': index, 'labels': labels, 'features': features}
#                     self.trajectories[traj_idx].append(checkin)
#                 if flag:
#                     self.trajectories.pop(traj_idx)
#             # if trajectory's length is way too long, it can cause the GPU to run out of memory, so split it.
#             # if the splitted trajectory's length is still bigger than 15, then we just retain the last 15 checkins
#             else:
#                 self.trajectories.pop(traj_idx)
#                 for date, traj in trajectory.groupby(trajectory['local_time'].dt.date):
#                     traj_idx = len(self.trajectories)
#                     self.trajectories[traj_idx] = []
#                     if len(traj) <= nary + 1:
#                         self.trajectories.pop(traj_idx)
#                         continue
#                     offset = 0 if len(traj) <= 15 else len(traj) - 15
#                     flag = 0
#                     for index in range(offset, len(traj) - 1):
#                         _, pid, _, _, _, lat, long, _, _, _, _, norm_in_day, _, _, _ = traj.iloc[index]
#                         _, next_pid, _, _, _, _, _, _, _, _, _, next_norm_in_day, _, _, _ = traj.iloc[index + 1]
#                         # Avoid exception
#                         if pid not in POI_id2idx_dict.keys() or next_pid not in POI_id2idx_dict.keys():
#                             flag = 1
#                             break
#                         POI_idx = POI_id2idx_dict[pid]
#                         cat_idx = POI_idx2cat_idx_dict[POI_idx]
#                         next_POI_idx = POI_id2idx_dict[next_pid]
#                         next_cat_idx = POI_idx2cat_idx_dict[next_POI_idx]
#                         features = [user_idx, POI_idx, cat_idx, (lat, long), norm_in_day]
#                         labels = [next_POI_idx, next_norm_in_day, next_cat_idx]
#                         checkin = {'index': index - offset, 'labels': labels, 'features': features}
#                         self.trajectories[traj_idx].append(checkin)
#                     if flag:
#                         self.trajectories.pop(traj_idx)
#         print(len(self.trajectories))
#
#     def __len__(self):
#         return len(self.trajectories)
#
#     def __getitem__(self, item):
#         return self.trajectories[item]

class TrajectoryDataset(Dataset):
    def __init__(self, data_df, user_id2idx_dict, POI_id2idx_dict, POI_idx2cat_idx_dict, nary, desc='train'):
        self.trajectories = {}

        data_df['local_time'] = pd.to_datetime(data_df['local_time'])  # convert time column to datetime format
        data_df = data_df.sort_values(['user_id', 'local_time'])  # sort

        for trajectory_id, trajectory in tqdm(data_df.groupby('trajectory_id'), desc=f"Prepare {desc} dataset"):
            if len(trajectory) <= nary + 1:  # ensure the trajectory's length can be converted to a tree
                continue
            user_id = trajectory_id.split('_')[0]
            # Avoid exception
            if user_id not in user_id2idx_dict.keys():
                continue
            user_idx = user_id2idx_dict[user_id]
            traj_idx = len(self.trajectories)
            self.trajectories[traj_idx] = []

            offset = 0 if len(trajectory) <= 15 else len(trajectory) - 15
            flag = 0
            for index in range(offset, len(trajectory) - 1):
                _, pid, _, _, _, lat, long, _, _, _, _, norm_in_day, _, _, _ = trajectory.iloc[index]
                _, next_pid, _, _, _, _, _, _, _, _, _, next_norm_in_day, _, _, _ = trajectory.iloc[index + 1]
                # Avoid exception
                if pid not in POI_id2idx_dict.keys() or next_pid not in POI_id2idx_dict.keys():
                    flag = 1
                    break
                POI_idx = POI_id2idx_dict[pid]
                cat_idx = POI_idx2cat_idx_dict[POI_idx]
                next_POI_idx = POI_id2idx_dict[next_pid]
                next_cat_idx = POI_idx2cat_idx_dict[next_POI_idx]
                features = [user_idx, POI_idx, cat_idx, norm_in_day]
                labels = [next_POI_idx, next_norm_in_day, next_cat_idx]
                checkin = {'index': index - offset, 'labels': labels, 'features': features}
                self.trajectories[traj_idx].append(checkin)
            if flag:
                self.trajectories.pop(traj_idx)

        print(f"{desc} dataset's length: {len(self.trajectories)}")

    def __len__(self):
        return len(self.trajectories)

    def __getitem__(self, item):
        return self.trajectories[item]
