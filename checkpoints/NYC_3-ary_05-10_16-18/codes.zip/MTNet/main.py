import yaml
import time
import random
import pickle
import zipfile
import logging
import collections

from model import *
from utils import *
from config import *
from dataset import *

SSTBatch = collections.namedtuple(
    "SSTBatch", ["graph", "features", "label"]
)


def setup_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


if __name__ == '__main__':
    # ==================================================================================================
    # 1. Get experiment args and seed
    # ==================================================================================================
    print('\n' + '=' * 36 + ' Get experiment args ' + '=' * 36)
    args = get_args()
    setup_seed(args.seed)  # make the experiment repeatable

    # ==================================================================================================
    # 2. Setup logger
    # ==================================================================================================
    print('\n' + '=' * 36 + ' Setup logger ' + '=' * 36)
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)
    logging_time = time.strftime('%m-%d_%H-%M', time.localtime())
    save_dir = os.path.join(args.save_path, args.dataset + '_' + str(args.nary) + '-ary_' + logging_time)
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    print(f"Saving path: {save_dir}")
    logging.basicConfig(level=logging.INFO,
                        format='[%(asctime)s %(levelname)s]%(message)s',
                        datefmt='%Y-%m-%d %H:%M:%S',
                        filename=os.path.join(save_dir, 'running.log'))
    console = logging.StreamHandler()  # Simultaneously output to console
    console.setLevel(logging.INFO)
    console.setFormatter(logging.Formatter(fmt='[%(asctime)s %(levelname)s]%(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
    logging.getLogger('').addHandler(console)
    logging.getLogger('matplotlib.font_manager').disabled = True

    # ==================================================================================================
    # 3. Save codes and settings
    # ==================================================================================================
    print('\n' + '=' * 36 + ' Save codes and settings ' + '=' * 36)
    zipf = zipfile.ZipFile(file=os.path.join(save_dir, 'codes.zip'), mode='a', compression=zipfile.ZIP_DEFLATED)
    zipdir(Path().absolute(), zipf, include_format=['.py'])
    zipf.close()
    with open(os.path.join(save_dir, 'args.yml'), 'a') as f:
        yaml.dump(vars(args), f, sort_keys=False)

    # ==================================================================================================
    # 4. Prepare data
    # ==================================================================================================
    print('\n' + '=' * 36 + ' Prepare data ' + '=' * 36)
    # Load data
    train_df = pd.read_csv(f'dataset/{args.dataset}/{args.dataset}_train.csv')
    val_df = pd.read_csv(f'dataset/{args.dataset}/{args.dataset}_val.csv')
    test_df = pd.read_csv(f'dataset/{args.dataset}/{args.dataset}_test.csv')

    # User id to index
    uid_list = [str(uid) for uid in list(set(train_df['user_id'].to_list()))]
    user_id2idx_dict = dict(zip(uid_list, range(len(uid_list))))
    # POI id to index
    POI_list = list(set(train_df['POI_id'].tolist()))
    POI_id2idx_dict = dict(zip(POI_list, range(len(POI_list))))
    # Cat id to index
    cat_ids = list(set(train_df['POI_catid'].tolist()))
    cat_id2idx_dict = dict(zip(cat_ids, range(len(cat_ids))))
    # POI index to cat index
    POI_idx2cat_idx_dict = {}
    for i, row in train_df.iterrows():
        POI_idx2cat_idx_dict[POI_id2idx_dict[row['POI_id']]] = cat_id2idx_dict[row['POI_catid']]
    map_set = (user_id2idx_dict, POI_id2idx_dict, POI_idx2cat_idx_dict)

    n_clusters = args.lon_parts * args.lat_parts
    max_lon, min_lon = train_df.loc[:, "longitude"].max() + 1, train_df.loc[:, "longitude"].min() - 1
    max_lat, min_lat = train_df.loc[:, "latitude"].max() + 1, train_df.loc[:, "latitude"].min() - 1
    column = (max_lon - min_lon) / args.lon_parts
    row = (max_lat - min_lat) / args.lat_parts


    def gen_coo_ID(lon, lat):
        if lon <= min_lon or lon >= max_lon or lat <= min_lat or lat >= max_lat:
            return -1
        return int((lon - min_lon) / column) + 1 + int((lat - min_lat) / row) * args.lon_parts


    train_df['coo_label'] = train_df.apply(lambda x: gen_coo_ID(x['longitude'], x['latitude']), axis=1)
    val_df['coo_label'] = val_df.apply(lambda x: gen_coo_ID(x['longitude'], x['latitude']), axis=1)
    test_df['coo_label'] = test_df.apply(lambda x: gen_coo_ID(x['longitude'], x['latitude']), axis=1)

    # Build dataset
    train_dataset = TrajectoryTrainDataset(train_df, map_set)
    val_dataset = TrajectoryValDataset(val_df, map_set)
    test_dataset = TrajectoryTestDataset(test_df, map_set)
    train_dataloader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, drop_last=False,
                                  pin_memory=True, num_workers=args.workers, collate_fn=lambda x: x)
    val_dataloader = DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False, drop_last=False,
                                pin_memory=True, num_workers=args.workers, collate_fn=lambda x: x)
    test_dataloader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False, drop_last=False,
                                 pin_memory=True, num_workers=args.workers, collate_fn=lambda x: x)

    # ==================================================================================================
    # 5. Build models
    # ==================================================================================================
    print('\n' + '=' * 36 + ' Build models ' + '=' * 36)
    num_users = len(user_id2idx_dict)
    num_POIs = len(POI_id2idx_dict)
    num_cats = len(cat_id2idx_dict)
    TreeLSTM_model = TreeLSTM(h_size=args.h_size,
                              dropout=args.dropout,
                              num_users=num_users, user_embed_dim=args.user_embed_dim,
                              num_POIs=num_POIs, POI_embed_dim=args.POI_embed_dim,
                              num_cats=num_cats, cat_embed_dim=args.cat_embed_dim,
                              num_coos=n_clusters, coo_embed_dim=args.coo_embed_dim,
                              time_embed_dim=args.time_embed_dim,
                              cell_type=args.cell_type, nary=args.nary,
                              head_num=args.transformer_head_num, hid_dim=args.transformer_hid_dim,
                              layer_num=args.transformer_layer_num, t_dropout=args.transformer_dropout,
                              device=args.device).to(device=args.device)
    if args.load_path:
        TreeLSTM_model.load_state_dict(torch.load(os.path.join(args.load_path, f"TreeLSTM_200.pkl")))
    logging.info(f"\n{TreeLSTM_model}")

    # ==================================================================================================
    # 6. Define overall loss and optimizer
    # ==================================================================================================
    optimizer = torch.optim.Adam(params=list(TreeLSTM_model.parameters()), lr=args.lr, weight_decay=args.weight_decay)

    criterion_POI = nn.CrossEntropyLoss(ignore_index=-1)  # -1 is ignored
    criterion_cat = nn.CrossEntropyLoss(ignore_index=-1)

    lr_scheduler = \
        torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', verbose=True, factor=args.lr_scheduler_factor)

    # ==================================================================================================
    # 7. Training and validation
    # ==================================================================================================
    print('\n' + '=' * 36 + ' Start training ' + '=' * 36)
    # Training loop
    for epoch in range(args.epochs):
        TreeLSTM_model.train()
        # Performance saver
        acc1_list, acc5_list, acc10_list, acc20_list, mrr_list, mAP_list, loss_list = [], [], [], [], [0], [], []

        for b_idx, batch in tqdm(enumerate(train_dataloader), total=len(train_dataloader), desc="Training"):
            batcher = []
            for trajectory in batch:
                trajectory_tree = construct_dgl_tree(trajectory, args.cell_type, args.nary, args.need_plot_tree)
                batcher.append(trajectory_tree.to(device=args.device))

            batch_trees = dgl.batch(batcher).to(device=args.device)
            batch_input = SSTBatch(graph=batch_trees,
                                   features=batch_trees.ndata["x"].to(device=args.device),
                                   label=batch_trees.ndata["y"].to(device=args.device))

            g = batch_input.graph.to(device=args.device)
            n = g.num_nodes()
            h = torch.zeros((n, args.h_size)).to(device=args.device)
            c = torch.zeros((n, args.h_size)).to(device=args.device)
            h_child = torch.zeros((n, args.nary, args.h_size)).to(device=args.device)
            c_child = torch.zeros((n, args.nary, args.h_size)).to(device=args.device)

            y_POI, y_cat, y_coo = batch_input.label[:, 0], batch_input.label[:, 1], batch_input.label[:, 2]
            y_pred_POI, y_pred_cat = TreeLSTM_model(batch_input, g, h, c, h_child, c_child)

            loss_POI = criterion_POI(y_pred_POI, y_POI.long())
            loss_cat = criterion_cat(y_pred_cat, y_cat.long())
            loss = loss_POI + loss_cat

            optimizer.zero_grad()
            loss.backward(retain_graph=True)
            optimizer.step()

            # Measurement
            loss_list.append(loss.item())
            y_pred_numpy = y_pred_POI.detach().cpu().numpy()
            batch_labels_numpy = y_POI.detach().cpu().numpy()
            acc1_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=1))
            acc5_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=5))
            acc10_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=10))
            acc20_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=20))
            # mrr_list.append(MRR_metric(batch_labels_numpy, y_pred_numpy))
            mAP_list.append(mAP_metric(batch_labels_numpy, y_pred_numpy, k=20))

        # Logging
        logging.info(f"************************  Training epoch: {epoch + 1}/{args.epochs}  ************************")
        logging.info(f"Current epoch's mean loss: {np.mean(loss_list)}")
        logging.info(f"acc@1: {np.mean(acc1_list)}\tacc@5: {np.mean(acc5_list)}\t"
                     f"acc@10: {np.mean(acc10_list)}\tacc@20: {np.mean(acc20_list)}\t"
                     f"mrr: {np.mean(mrr_list)}\tmAP: {np.mean(mAP_list)}")

        # ==================================================================================================
        # 8. Evaluation
        # ==================================================================================================
        # TreeLSTM_model.eval()
        #
        # acc1_list, acc5_list, acc10_list, acc20_list, mrr_list, mAP_list, loss_list = [], [], [], [], [0], [], []
        # # Start evaluation
        # for batch in val_dataloader:
        #     batcher = []
        #     for trajectory in batch:
        #         trajectory_tree = construct_dgl_tree(trajectory, args.cell_type, args.nary, args.need_plot_tree)
        #         batcher.append(trajectory_tree.to(device=args.device))
        #
        #     batch_trees = dgl.batch(batcher).to(device=args.device)
        #     batch_input = SSTBatch(graph=batch_trees,
        #                            features=batch_trees.ndata["x"].to(device=args.device),
        #                            label=batch_trees.ndata["y"].to(device=args.device))
        #
        #     g = batch_input.graph.to(device=args.device)
        #     n = g.num_nodes()
        #     h = torch.zeros((n, args.h_size)).to(device=args.device)
        #     c = torch.zeros((n, args.h_size)).to(device=args.device)
        #     h_child = torch.zeros((n, args.nary, args.h_size)).to(device=args.device)
        #     c_child = torch.zeros((n, args.nary, args.h_size)).to(device=args.device)
        #
        #     y_POI, y_cat, y_coo = batch_input.label[:, 0], batch_input.label[:, 1], batch_input.label[:, 2]
        #     y_pred_POI, y_pred_cat = TreeLSTM_model(batch_input, g, h, c, h_child, c_child)
        #
        #     loss_POI = criterion_POI(y_pred_POI, y_POI.long())
        #     loss_cat = criterion_cat(y_pred_cat, y_cat.long())
        #     loss = loss_POI + loss_cat
        #
        #     # Measurement
        #     loss_list.append(loss.item())
        #     y_pred_numpy = y_pred_POI.detach().cpu().numpy()
        #     batch_labels_numpy = y_POI.detach().cpu().numpy()
        #     acc1_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=1))
        #     acc5_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=5))
        #     acc10_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=10))
        #     acc20_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=20))
        #     # mrr_list.append(MRR_metric(batch_labels_numpy, y_pred_numpy))
        #     mAP_list.append(mAP_metric(batch_labels_numpy, y_pred_numpy, k=20))
        #
        # # Logging
        # logging.info(f"---------------------------- validation ----------------------------")
        # logging.info(f"Mean loss: {np.mean(loss_list)}")
        # logging.info(f"acc@1: {np.mean(acc1_list)}\tacc@5: {np.mean(acc5_list)}\t"
        #              f"acc@10: {np.mean(acc10_list)}\tacc@20: {np.mean(acc20_list)}\t"
        #              f"mrr: {np.mean(mrr_list)}\tmAP: {np.mean(mAP_list)}\n")

        # Save model
        if (epoch + 1) >= args.epochs * 0.9 or (epoch + 1) % 50 == 0:
            torch.save(TreeLSTM_model.state_dict(), os.path.join(save_dir, f"TreeLSTM_{epoch + 1}.pkl"))

        # ==================================================================================================
        # 9. Testing
        # ==================================================================================================
        TreeLSTM_model.eval()

        acc1_list, acc5_list, acc10_list, acc20_list, mrr_list, mAP_list = [], [], [], [], [0], []
        # Start testing
        for batch in test_dataloader:
            batcher = []
            for trajectory in batch:
                trajectory_tree = construct_dgl_tree(trajectory, args.cell_type, args.nary, args.need_plot_tree)
                batcher.append(trajectory_tree.to(device=args.device))

            batch_trees = dgl.batch(batcher).to(device=args.device)
            batch_input = SSTBatch(graph=batch_trees,
                                   features=batch_trees.ndata["x"].to(device=args.device),
                                   label=batch_trees.ndata["y"].to(device=args.device))

            g = batch_input.graph.to(device=args.device)
            n = g.num_nodes()
            h = torch.zeros((n, args.h_size)).to(device=args.device)
            c = torch.zeros((n, args.h_size)).to(device=args.device)
            h_child = torch.zeros((n, args.nary, args.h_size)).to(device=args.device)
            c_child = torch.zeros((n, args.nary, args.h_size)).to(device=args.device)

            y_POI, y_cat, y_coo = batch_input.label[:, 0], batch_input.label[:, 1], batch_input.label[:, 2]
            y_pred_POI, y_pred_cat = TreeLSTM_model(batch_input, g, h, c, h_child, c_child)

            # Measurement
            y_pred_numpy = y_pred_POI.detach().cpu().numpy()
            batch_labels_numpy = y_POI.detach().cpu().numpy()
            acc1_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=1))
            acc5_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=5))
            acc10_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=10))
            acc20_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=20))
            # mrr_list.append(MRR_metric(batch_labels_numpy, y_pred_numpy))
            mAP_list.append(mAP_metric(batch_labels_numpy, y_pred_numpy, k=20))

        # Logging
        logging.info(f"================================ Testing ================================")
        logging.info(f"acc@1: {np.mean(acc1_list)}\tacc@5: {np.mean(acc5_list)}\t"
                     f"acc@10: {np.mean(acc10_list)}\tacc@20: {np.mean(acc20_list)}\t"
                     f"mrr: {np.mean(mrr_list)}\tmAP: {np.mean(mAP_list)}\n")
