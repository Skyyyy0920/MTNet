import os
import re
import dgl
import glob
import numpy as np
import networkx as nx
from pathlib import Path
import matplotlib.pyplot as plt


def zipdir(path, zipf, include_format):
    for root, dirs, files in os.walk(path):
        for file in files:
            if os.path.splitext(file)[-1] in include_format:
                filename = os.path.join(root, file)
                arcname = os.path.relpath(os.path.join(root, file), os.path.join(path, '..'))
                zipf.write(filename, arcname)


def increment_path(path, exist_ok=True, sep=''):
    # Increment path, i.e. runs/exp --> runs/exp{sep}0, runs/exp{sep}1 etc.
    path = Path(path)  # os-agnostic
    if (path.exists() and exist_ok) or (not path.exists()):
        return str(path)
    else:
        dirs = glob.glob(f"{path}{sep}*")  # similar paths
        matches = [re.search(rf"%s{sep}(\d+)" % path.stem, d) for d in dirs]
        i = [int(m.groups()[0]) for m in matches if m]  # indices
        n = max(i) + 1 if i else 2  # increment number
        return f"{path}{sep}{n}"  # update path


def masked_mse_loss(input, target, mask_value=-1):
    mask = target == mask_value
    out = (input[~mask] - target[~mask]) ** 2
    loss = out.mean()
    return loss


def top_k_acc(y_true_seq, y_pred_seq, k):
    hit = 0
    # Convert to binary relevance (nonzero is relevant).
    for y_true, y_pred in zip(y_true_seq, y_pred_seq):
        top_k_rec = y_pred.argsort()[-k:][::-1]
        idx = np.where(top_k_rec == y_true)[0]
        if len(idx) != 0:
            hit += 1
    return hit / len(y_true_seq)


def mAP_metric(y_pred_seq, y_true_seq, k):
    # AP: area under PR curve
    # But in next POI rec, the number of positive sample is always 1. Precision is not well defined.
    # Take def of mAP from Personalized Long- and Short-term Preference Learning for Next POI Recommendation
    rlt = 0
    for y_true, y_pred in zip(y_true_seq, y_pred_seq):
        rec_list = y_pred.argsort()[-k:][::-1]
        r_idx = np.where(rec_list == y_true)[0]
        if len(r_idx) != 0:
            rlt += 1 / (r_idx[0] + 1)
    return rlt / len(y_true_seq)


def MRR_metric(y_pred_seq, y_true_seq):
    """Mean Reciprocal Rank: Reciprocal of the rank of the first relevant item """
    rlt = 0
    for y_true, y_pred in zip(y_true_seq, y_pred_seq):
        rec_list = y_pred.argsort()[-len(y_pred):][::-1]
        r_idx = np.where(rec_list == y_true)[0][0]
        rlt += 1 / (r_idx + 1)
    return rlt / len(y_true_seq)


def array_round(x, k=4):
    # For a list of float values, keep k decimals of each element
    return list(np.around(np.array(x), k))


# ===================================================================================================================
def plot_tree(g):
    # this plot requires pygraphviz package
    pos = nx.nx_agraph.graphviz_layout(g, prog="dot")
    nx.draw_networkx(g,
                     pos,
                     with_labels=True,
                     node_size=20,
                     node_color=[[0.5, 0.5, 0.5]],
                     arrowsize=8)
    plt.show()


def add_children(tree, trajectory, index, idx2idx_dict, flag_dict, nary):
    """
    Using DFS to construct the tree
    """
    node = trajectory[index]
    idx2idx_dict[index] = tree.number_of_nodes()
    tree.add_node(idx2idx_dict[index], x=node['features'], y=node['labels'])
    if index >= nary and flag_dict[index]:
        flag_dict[index] = 0  # already play as parent node
        for i in range(nary, 0, -1):
            add_children(tree, trajectory, index - i, idx2idx_dict, flag_dict, nary)
            tree.add_edge(idx2idx_dict[index - i], idx2idx_dict[index])  # src -> dst
    else:
        pass

    return


def construct_dgl_tree(trajectory, nary, need_plot=False):
    """
    Prepare the data structure for dgl tree
    :param trajectory:  a list contains a series of check-ins {'index': int, 'labels': [], 'feature_embedding': []}
    :param nary: construct n-ary tree
    :param need_plot: bool, whether to plot
    :return: dgl.DGLGraph
    """
    tree = nx.DiGraph()
    idx2idx_dict = {}
    flag_dict = dict(zip(range(len(trajectory)), np.ones(len(trajectory))))
    add_children(tree, trajectory, len(trajectory) - 1, idx2idx_dict, flag_dict, nary)
    if need_plot:
        plot_tree(tree)  # optional
    dgl_tree = dgl.from_networkx(tree, node_attrs=['x', 'y'])
    return dgl_tree
