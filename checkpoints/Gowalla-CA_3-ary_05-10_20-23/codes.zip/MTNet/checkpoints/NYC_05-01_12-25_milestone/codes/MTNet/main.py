import yaml
import pickle
import zipfile
import logging
import collections
from torch.nn.utils.rnn import pad_sequence
from sklearn.preprocessing import OneHotEncoder

from model import *
from utils import *
from config import *
from dataset import *

SSTBatch = collections.namedtuple(
    "SSTBatch", ["graph", "mask", "embedding", "label"]
)

if __name__ == '__main__':
    os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
    # ==================================================================================================
    # 1. Get experiment args
    # ==================================================================================================
    print('\n' + '=' * 36 + ' Get experiment args ' + '=' * 36)
    args = get_args()
    for key, item in vars(args).items():
        print(f'{key}: {item}')

    # ==================================================================================================
    # 2. Setup logger
    # ==================================================================================================
    print('\n' + '=' * 36 + ' Setup logger ' + '=' * 36)
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)
    logging_time = time.strftime('%m-%d_%H-%M', time.localtime())
    save_dir = os.path.join(args.save_path, args.dataset + '_' + logging_time)
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    print(f"Saving path: {save_dir}")
    logging.basicConfig(level=logging.INFO,
                        format='[%(asctime)s %(levelname)s]%(message)s',
                        datefmt='%Y-%m-%d %H:%M:%S',
                        filename=os.path.join(save_dir, 'running.log'))
    console = logging.StreamHandler()  # Simultaneously output to console
    console.setLevel(logging.INFO)
    console.setFormatter(logging.Formatter(fmt='[%(asctime)s %(levelname)s]%(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
    logging.getLogger('').addHandler(console)
    logging.getLogger('matplotlib.font_manager').disabled = True

    # ==================================================================================================
    # 3. Save codes and settings
    # ==================================================================================================
    print('\n' + '=' * 36 + ' Save codes and settings ' + '=' * 36)
    zipf = zipfile.ZipFile(file=os.path.join(save_dir, 'codes.zip'),
                           mode='a', compression=zipfile.ZIP_DEFLATED)
    zipdir(Path().absolute(), zipf, include_format=['.py'])
    zipf.close()
    with open(os.path.join(save_dir, 'args.yml'), 'a') as f:
        yaml.dump(vars(args), f, sort_keys=False)

    # ==================================================================================================
    # 4. Prepare data
    # ==================================================================================================
    print('\n' + '=' * 36 + ' Prepare data ' + '=' * 36)
    # Load data
    train_df = pd.read_csv(args.data_train)
    val_df = pd.read_csv(args.data_val)
    test_df = pd.read_csv(args.data_test)

    # User id to index
    uid_list = [str(uid) for uid in list(set(train_df['user_id'].to_list()))]
    user_id2idx_dict = dict(zip(uid_list, range(len(uid_list))))
    # POI id to index
    POI_list = list(set(train_df['POI_id'].tolist()))
    POI_id2idx_dict = dict(zip(POI_list, range(len(POI_list))))
    # Cat id to index
    cat_ids = list(set(train_df['POI_catid'].tolist()))
    cat_id2idx_dict = dict(zip(cat_ids, range(len(cat_ids))))
    # POI index to cat index
    poi_idx2cat_idx_dict = {}
    for i, row in train_df.iterrows():
        poi_idx2cat_idx_dict[POI_id2idx_dict[row['POI_id']]] = cat_id2idx_dict[row['POI_catid']]

    # Build dataset
    train_dataset = TrajectoryDataset(train_df, user_id2idx_dict, POI_id2idx_dict, poi_idx2cat_idx_dict, 'train')
    val_dataset = TrajectoryDataset(val_df, user_id2idx_dict, POI_id2idx_dict, poi_idx2cat_idx_dict, 'val')
    test_dataset = TrajectoryDataset(test_df, user_id2idx_dict, POI_id2idx_dict, poi_idx2cat_idx_dict, 'test')
    train_dataloader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, drop_last=False,
                                  pin_memory=True, num_workers=args.workers, collate_fn=lambda x: x)
    val_dataloader = DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False, drop_last=False,
                                pin_memory=True, num_workers=args.workers, collate_fn=lambda x: x)
    test_dataloader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False, drop_last=False,
                                 pin_memory=True, num_workers=args.workers, collate_fn=lambda x: x)

    # ==================================================================================================
    # 5. Build models
    # ==================================================================================================
    print('\n' + '=' * 36 + ' Build models ' + '=' * 36)
    # User embedding model
    num_users = len(user_id2idx_dict)
    user_embed_model = UserEmbeddings(num_users, args.user_embed_dim).to(device=args.device)
    logging.info(f"\n{user_embed_model}")
    # POI embedding model
    num_POIs = len(POI_id2idx_dict)
    POI_embed_model = POIEmbeddings(num_POIs, args.poi_embed_dim).to(device=args.device)
    logging.info(f"\n{POI_embed_model}")
    # Category embedding model
    num_cats = len(cat_id2idx_dict)
    cat_embed_model = CategoryEmbeddings(num_cats, args.cat_embed_dim).to(device=args.device)
    logging.info(f"\n{cat_embed_model}")
    # Time embedding model
    time_embed_model = Time2Vec('sin', out_dim=args.time_embed_dim).to(device=args.device)
    logging.info(f"\n{time_embed_model}")
    # LSTMTree model
    in_features = args.user_embed_dim + args.poi_embed_dim + args.cat_embed_dim + args.time_embed_dim
    TreeLSTM_model = TreeLSTM(embedding_dim=in_features,
                              h_size=args.h_size,
                              dropout=0.5,
                              cell_type=args.cell_type,
                              nary=args.nary).to(device=args.device)
    logging.info(f"\n{TreeLSTM_model}")

    # ==================================================================================================
    # 6. Define overall loss and optimizer
    # ==================================================================================================
    optimizer = torch.optim.Adam(params=list(user_embed_model.parameters()) + list(POI_embed_model.parameters()) +
                                        list(cat_embed_model.parameters()) + list(time_embed_model.parameters()) +
                                        list(TreeLSTM_model.parameters()),
                                 lr=args.lr, weight_decay=args.weight_decay)

    criterion_POI = nn.CrossEntropyLoss(ignore_index=-1)  # -1 is padding
    criterion_cat = nn.CrossEntropyLoss(ignore_index=-1)
    criterion_time = maksed_mse_loss

    lr_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', verbose=True,
                                                              factor=args.lr_scheduler_factor)

    # ==================================================================================================
    # 7. Training and validation
    # ==================================================================================================
    print('\n' + '=' * 36 + ' Start training ' + '=' * 36)
    # Training loop
    for epoch in range(args.epochs):
        # Train mode
        user_embed_model.train()
        POI_embed_model.train()
        cat_embed_model.train()
        time_embed_model.train()
        TreeLSTM_model.train()
        # Performance saver
        acc1_list, acc5_list, acc10_list, acc20_list, mrr_list, mAP_list, loss_list = [], [], [], [], [0], [0], []

        # for b_idx, batch in enumerate(train_dataloader):
        for batch in train_dataloader:
            batcher = []
            for trajectories in batch:
                for index in trajectories:
                    if len(trajectories[index]) > 20:
                        continue
                    for checkin in trajectories[index]:
                        features = checkin['features']
                        user_idx, pid, cid, (lat, long), time, trajectory_id = features
                        # user embedding
                        u_input = torch.tensor([user_idx]).to(device=args.device)
                        user_embedding = user_embed_model(u_input)
                        user_embedding = torch.squeeze(user_embedding)
                        # poi embedding
                        p_input = torch.tensor([pid]).to(device=args.device)
                        poi_embedding = POI_embed_model(p_input)
                        poi_embedding = torch.squeeze(poi_embedding)
                        # category embedding
                        c_input = torch.tensor([cid]).to(device=args.device)
                        cat_embedding = cat_embed_model(c_input)
                        cat_embedding = torch.squeeze(cat_embedding)
                        # time embedding
                        t_input = torch.tensor([time], dtype=torch.float).to(device=args.device)
                        time_embedding = time_embed_model(t_input)
                        time_embedding = torch.squeeze(time_embedding)
                        # concat
                        concat_embedding = torch.cat([user_embedding, time_embedding, poi_embedding, cat_embedding],
                                                     dim=0)
                        checkin['feature_embedding'] = concat_embedding

                    trajectory_tree = construct_dgl_tree(trajectories[index], args.need_plot)
                    batcher.append(trajectory_tree.to(device=args.device))

            batch_trees = dgl.batch(batcher).to(device=args.device)
            batch_input = SSTBatch(graph=batch_trees,
                                   mask=batch_trees.ndata["mask"].to(device=args.device),
                                   embedding=batch_trees.ndata["x"].to(device=args.device),
                                   label=batch_trees.ndata["y"].to(device=args.device))

            g = batch_input.graph.to(device=args.device)
            n = g.num_nodes()
            h = torch.zeros((n, args.h_size)).to(device=args.device)
            c = torch.zeros((n, args.h_size)).to(device=args.device)
            h_child = torch.zeros((n, args.nary, args.h_size)).to(device=args.device)
            c_child = torch.zeros((n, args.nary, args.h_size)).to(device=args.device)

            # y_POI, y_time, y_cat = batch_input.label[:, 0], batch_input.label[:, 1], batch_input.label[:, 2]
            y_POI = batch_input.label
            # y_pred_POI, y_pred_time, y_pred_cat = TreeLSTM_model(batch_input, g, h, c, h_child, c_child)
            y_pred_POI = TreeLSTM_model(batch_input, g, h, c, h_child, c_child)
            y_pred = torch.mm(y_pred_POI, POI_embed_model.POI_embedding.weight.transpose(1, 0))

            # loss_time = criterion_time(y_pred_time, y_time)
            # loss_cat = criterion_cat(y_pred_cat, y_cat)
            # loss_POI = criterion_POI(y_pred_POI, y_POI)
            logp = F.log_softmax(y_pred, 1)
            loss = F.nll_loss(logp, y_POI, reduction="sum")
            # Final loss
            # loss = loss_POI + loss_time * args.time_loss_weight + loss_cat

            optimizer.zero_grad()
            loss.backward(retain_graph=True)
            optimizer.step()

            # Measurement
            loss_list.append(loss.detach().cpu().numpy())
            y_pred_numpy = y_pred.detach().cpu().numpy()
            batch_labels_numpy = batch_input.label.detach().cpu().numpy()
            acc1_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=1))
            acc5_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=5))
            acc10_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=10))
            acc20_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=20))
            # mrr_list.append(MRR_metric(y_pred_numpy, batch_labels_numpy))
            # mAP_list.append(mAP_metric(y_pred_numpy, batch_labels_numpy, k=20))

        # Logging
        logging.info(f"************************  Training epoch: {epoch + 1}/{args.epochs}  ************************")
        logging.info(f"Current epoch's mean loss: {np.mean(loss_list)}")
        logging.info(f"acc@1: {np.mean(acc1_list)}\tacc@5: {np.mean(acc5_list)}\t"
                     f"acc@10: {np.mean(acc10_list)}\tacc@20: {np.mean(acc20_list)}\t"
                     f"mrr: {np.mean(mrr_list)}\tmAP: {np.mean(mAP_list)}")

        # Evaluation mode
        user_embed_model.eval()
        POI_embed_model.eval()
        cat_embed_model.eval()
        time_embed_model.eval()
        TreeLSTM_model.eval()

        acc1_list, acc5_list, acc10_list, acc20_list, mrr_list, mAP_list, loss_list = [], [], [], [], [0], [0], []
        # Start evaluation
        for batch in val_dataloader:
            batcher = []
            for trajectories in batch:
                for index in trajectories:
                    if len(trajectories[index]) > 20:
                        continue
                    for checkin in trajectories[index]:
                        features = checkin['features']
                        user_idx, pid, cid, (lat, long), time, trajectory_id = features
                        # user embedding
                        u_input = torch.tensor([user_idx]).to(device=args.device)
                        user_embedding = user_embed_model(u_input)
                        user_embedding = torch.squeeze(user_embedding)
                        # poi embedding
                        p_input = torch.tensor([pid]).to(device=args.device)
                        poi_embedding = POI_embed_model(p_input)
                        poi_embedding = torch.squeeze(poi_embedding)
                        # category embedding
                        c_input = torch.tensor([cid]).to(device=args.device)
                        cat_embedding = cat_embed_model(c_input)
                        cat_embedding = torch.squeeze(cat_embedding)
                        # time embedding
                        t_input = torch.tensor([time], dtype=torch.float).to(device=args.device)
                        time_embedding = time_embed_model(t_input)
                        time_embedding = torch.squeeze(time_embedding)
                        # concat
                        concat_embedding = torch.cat([user_embedding, time_embedding, poi_embedding, cat_embedding],
                                                     dim=0)
                        checkin['feature_embedding'] = concat_embedding

                    trajectory_tree = construct_dgl_tree(trajectories[index], args.need_plot)
                    batcher.append(trajectory_tree.to(device=args.device))

            batch_trees = dgl.batch(batcher).to(device=args.device)
            batch_input = SSTBatch(graph=batch_trees,
                                   mask=batch_trees.ndata["mask"].to(device=args.device),
                                   embedding=batch_trees.ndata["x"].to(device=args.device),
                                   label=batch_trees.ndata["y"].to(device=args.device))

            g = batch_input.graph.to(device=args.device)
            n = g.num_nodes()
            h = torch.zeros((n, args.h_size)).to(device=args.device)
            c = torch.zeros((n, args.h_size)).to(device=args.device)
            h_child = torch.zeros((n, args.nary, args.h_size)).to(device=args.device)
            c_child = torch.zeros((n, args.nary, args.h_size)).to(device=args.device)

            # y_POI, y_time, y_cat = batch_input.label[:, 0], batch_input.label[:, 1], batch_input.label[:, 2]
            y_POI = batch_input.label
            # y_pred_POI, y_pred_time, y_pred_cat = TreeLSTM_model(batch_input, g, h, c, h_child, c_child)
            y_pred_POI = TreeLSTM_model(batch_input, g, h, c, h_child, c_child)
            y_pred = torch.mm(y_pred_POI, POI_embed_model.POI_embedding.weight.transpose(1, 0))

            # loss_time = criterion_time(y_pred_time, y_time)
            # loss_cat = criterion_cat(y_pred_cat, y_cat)
            # loss_POI = criterion_POI(y_pred_POI, y_POI)
            logp = F.log_softmax(y_pred, 1)
            loss = F.nll_loss(logp, y_POI, reduction="sum")
            # Final loss
            # loss = loss_POI + loss_time * args.time_loss_weight + loss_cat

            # Measurement
            loss_list.append(loss.detach().cpu().numpy())
            y_pred_numpy = y_pred.detach().cpu().numpy()
            batch_labels_numpy = batch_input.label.detach().cpu().numpy()
            acc1_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=1))
            acc5_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=5))
            acc10_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=10))
            acc20_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=20))
            # mrr_list.append(MRR_metric(y_pred_numpy, batch_labels_numpy))
            # mAP_list.append(mAP_metric(y_pred_numpy, batch_labels_numpy, k=20))

        # Logging
        logging.info(f"---------------------------- validation ----------------------------")
        logging.info(f"Mean loss: {np.mean(loss_list)}")
        logging.info(f"acc@1: {np.mean(acc1_list)}\tacc@5: {np.mean(acc5_list)}\t"
                     f"acc@10: {np.mean(acc10_list)}\tacc@20: {np.mean(acc20_list)}\t"
                     f"mrr: {np.mean(mrr_list)}\tmAP: {np.mean(mAP_list)}\n")

        # Save model
        if epoch > args.epochs * 0.8:
            torch.save(TreeLSTM_model.state_dict(), os.path.join(save_dir, f"TreeLSTM_{epoch+1}.pkl"))
            torch.save(user_embed_model.state_dict(), os.path.join(save_dir, f"user_embed_model_{epoch + 1}.pkl"))
            torch.save(POI_embed_model.state_dict(), os.path.join(save_dir, f"POI_embed_model_{epoch + 1}.pkl"))
            torch.save(cat_embed_model.state_dict(), os.path.join(save_dir, f"cat_embed_model_{epoch + 1}.pkl"))
            torch.save(time_embed_model.state_dict(), os.path.join(save_dir, f"time_embed_model_{epoch + 1}.pkl"))

    # ==================================================================================================
    # 8. Testing
    # ==================================================================================================
    acc1_list, acc5_list, acc10_list, acc20_list, mrr_list, mAP_list, loss_list = [], [], [], [], [0], [0], []
    # Start evaluation
    for batch in test_dataloader:
        batcher = []
        for trajectories in batch:
            for index in trajectories:
                if len(trajectories[index]) > 20:
                    continue
                for checkin in trajectories[index]:
                    features = checkin['features']
                    user_idx, pid, cid, (lat, long), time, trajectory_id = features
                    # user embedding
                    u_input = torch.tensor([user_idx]).to(device=args.device)
                    user_embedding = user_embed_model(u_input)
                    user_embedding = torch.squeeze(user_embedding)
                    # poi embedding
                    p_input = torch.tensor([pid]).to(device=args.device)
                    poi_embedding = POI_embed_model(p_input)
                    poi_embedding = torch.squeeze(poi_embedding)
                    # category embedding
                    c_input = torch.tensor([cid]).to(device=args.device)
                    cat_embedding = cat_embed_model(c_input)
                    cat_embedding = torch.squeeze(cat_embedding)
                    # time embedding
                    t_input = torch.tensor([time], dtype=torch.float).to(device=args.device)
                    time_embedding = time_embed_model(t_input)
                    time_embedding = torch.squeeze(time_embedding)
                    # concat
                    concat_embedding = torch.cat([user_embedding, time_embedding, poi_embedding, cat_embedding],
                                                 dim=0)
                    checkin['feature_embedding'] = concat_embedding

                trajectory_tree = construct_dgl_tree(trajectories[index], args.need_plot)
                batcher.append(trajectory_tree.to(device=args.device))

        batch_trees = dgl.batch(batcher).to(device=args.device)
        batch_input = SSTBatch(graph=batch_trees,
                               mask=batch_trees.ndata["mask"].to(device=args.device),
                               embedding=batch_trees.ndata["x"].to(device=args.device),
                               label=batch_trees.ndata["y"].to(device=args.device))

        g = batch_input.graph.to(device=args.device)
        n = g.num_nodes()
        h = torch.zeros((n, args.h_size)).to(device=args.device)
        c = torch.zeros((n, args.h_size)).to(device=args.device)
        h_child = torch.zeros((n, args.nary, args.h_size)).to(device=args.device)
        c_child = torch.zeros((n, args.nary, args.h_size)).to(device=args.device)

        # y_POI, y_time, y_cat = batch_input.label[:, 0], batch_input.label[:, 1], batch_input.label[:, 2]
        y_POI = batch_input.label
        # y_pred_POI, y_pred_time, y_pred_cat = TreeLSTM_model(batch_input, g, h, c, h_child, c_child)
        y_pred_POI = TreeLSTM_model(batch_input, g, h, c, h_child, c_child)
        y_pred = torch.mm(y_pred_POI, POI_embed_model.POI_embedding.weight.transpose(1, 0))

        # loss_time = criterion_time(y_pred_time, y_time)
        # loss_cat = criterion_cat(y_pred_cat, y_cat)
        # loss_POI = criterion_POI(y_pred_POI, y_POI)
        logp = F.log_softmax(y_pred, 1)
        loss = F.nll_loss(logp, y_POI, reduction="sum")
        # Final loss
        # loss = loss_POI + loss_time * args.time_loss_weight + loss_cat

        # Measurement
        loss_list.append(loss.detach().cpu().numpy())
        y_pred_numpy = y_pred.detach().cpu().numpy()
        batch_labels_numpy = batch_input.label.detach().cpu().numpy()
        acc1_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=1))
        acc5_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=5))
        acc10_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=10))
        acc20_list.append(top_k_acc(batch_labels_numpy, y_pred_numpy, k=20))
        # mrr_list.append(MRR_metric(y_pred_numpy, batch_labels_numpy))
        # mAP_list.append(mAP_metric(y_pred_numpy, batch_labels_numpy, k=20))

    # Logging
    logging.info(f"================================ Testing ================================")
    logging.info(f"Loss: {np.mean(loss_list)}")
    logging.info(f"acc@1: {np.mean(acc1_list)}\tacc@5: {np.mean(acc5_list)}\t"
                 f"acc@10: {np.mean(acc10_list)}\tacc@20: {np.mean(acc20_list)}\t"
                 f"mrr: {np.mean(mrr_list)}\tmAP: {np.mean(mAP_list)}\n")
